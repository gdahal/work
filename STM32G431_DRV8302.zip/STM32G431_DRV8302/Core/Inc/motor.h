#ifndef __MOTOR_H
#define __MOTOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32g4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/**
 * @brief Motor States
 */
typedef enum
{
    MOTOR_POWER_ON = 0,
    MOTOR_INIT,
    MOTOR_READY,
    MOTOR_ALIGNING,
    MOTOR_IDLE,
    MOTOR_RUNNING,
    MOTOR_STOPPING,
    MOTOR_FAULT
} MotorState_t;

/**
 * @brief Motor Direction
 */
typedef enum
{
    MOTOR_STOP = 0,
    MOTOR_FORWARD,
    MOTOR_BACKWARD
} MotorDirection_t;

/**
 * @brief Main Motor Control Structure
 */
typedef struct
{
    MotorState_t state;
    MotorDirection_t direction;
    MotorDirection_t requested_direction;
    
    bool gate_driver_enabled;
    uint8_t pwm_duty;            // Current PID output (0-100)
    
    float target_rpm;            // Final desired speed
    float current_target_rpm;    // Ramped target speed
    float speed_ramp_rate;       // Acceleration in RPM/sec
    
    uint16_t speed_rpm;          // Measured speed
    
    uint16_t stall_counter;      // Counter for stall detection
} MotorControl_t;

extern MotorControl_t Motor;

// Configuration Defaults
#define DEFAULT_SPEED_RAMP_RATE   500.0f  // RPM per second
#define STALL_PWM_THRESHOLD       70      // % Duty cycle
#define STALL_TIMEOUT_MS          300     // Milliseconds before stall fault
#define ALIGNMENT_TIME_MS         200     // Milliseconds for rotor alignment
#define ALIGNMENT_DUTY_CYCLE      15      // % Duty cycle during alignment
#define CONTROL_LOOP_PERIOD_S     0.02f   // 50Hz (20ms)

void Motor_Init(void);
void Motor_Process(void);
void Motor_ControlLoop(void);

void Motor_Enable(void);
void Motor_Disable(void);
void Motor_Start(void);
void Motor_Stop(void);
void Motor_SetForward(void);
void Motor_SetBackward(void);
void Motor_SetSpeed(uint16_t rpm);
void Motor_FaultTriggered(void);
void Motor_ResetFault(void);
void Motor_UpdateCommutation(void);

#ifdef __cplusplus
}
#endif

#endif /* __MOTOR_H */
