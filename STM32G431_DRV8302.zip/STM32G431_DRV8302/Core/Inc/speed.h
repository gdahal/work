#ifndef __SPEED_H
#define __SPEED_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

// Configurable Parameters
#define MOTOR_POLE_PAIRS 8
#define HALL_EDGES_PER_ELEC_REV 6

void Speed_Init(void);
void Speed_Update(void);
uint16_t Speed_GetRPM(void);
void Speed_HallCallback(uint16_t GPIO_Pin);
uint8_t Speed_GetHallState(void);

#ifdef __cplusplus
}
#endif

#endif /* __SPEED_H */
