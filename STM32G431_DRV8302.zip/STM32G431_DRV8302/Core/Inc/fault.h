#ifndef __FAULT_H
#define __FAULT_H

#ifdef __cplusplus
extern "C" {
#endif

void Fault_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* __FAULT_H */
