#ifndef __PROTOCOL_H
#define __PROTOCOL_H

#ifdef __cplusplus
extern "C" {
#endif

void Protocol_ProcessCommand(const char *cmd);

#ifdef __cplusplus
}
#endif

#endif /* __PROTOCOL_H */
