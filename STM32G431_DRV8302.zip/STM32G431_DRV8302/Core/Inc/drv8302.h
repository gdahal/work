#ifndef __DRV8302_H
#define __DRV8302_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32g4xx_hal.h"

/* Pin definitions for DRV8302 */
#define DRV_EN_PORT  GPIOA
#define DRV_EN_PIN   GPIO_PIN_11

/* Function Prototypes */
void DRV8302_Init(void);
void DRV8302_Enable(void);
void DRV8302_Disable(void);

#ifdef __cplusplus
}
#endif

#endif /* __DRV8302_H */
