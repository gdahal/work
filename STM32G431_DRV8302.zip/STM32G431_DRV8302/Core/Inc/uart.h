#ifndef __UART_H
#define __UART_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32g4xx_hal.h"
#include <stdint.h>

#define UART_RX_BUF_SIZE 128

void UART_Init(void);
void UART_SendMessage(const char *msg);
void UART_Process(void);

#ifdef __cplusplus
}
#endif

#endif /* __UART_H */
