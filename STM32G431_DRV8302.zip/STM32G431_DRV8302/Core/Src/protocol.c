#include "protocol.h"
#include "motor.h"
#include "uart.h"
#include "pid.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

extern PID_Controller speed_pid;

/**
 * @brief Parse and execute UART commands
 * @param cmd Null-terminated string received via UART
 */
void Protocol_ProcessCommand(const char *cmd)
{
    if (strncmp(cmd, "ENABLE", 6) == 0) {
        Motor_Enable();
    } 
    else if (strncmp(cmd, "DISABLE", 7) == 0) {
        Motor_Disable();
    } 
    else if (strncmp(cmd, "START", 5) == 0) {
        Motor_Start();
    } 
    else if (strncmp(cmd, "STOP", 4) == 0) {
        Motor_Stop();
    } 
    else if (strncmp(cmd, "FORWARD", 7) == 0) {
        Motor_SetForward();
    } 
    else if (strncmp(cmd, "BACKWARD", 8) == 0) {
        Motor_SetBackward();
    } 
    else if (strncmp(cmd, "SET_SPEED", 9) == 0) {
        int speed = 0;
        if (sscanf(cmd, "SET_SPEED %d", &speed) == 1) {
            Motor_SetSpeed((uint16_t)speed);
        } else {
            UART_SendMessage("Invalid Speed value\r\n");
        }
    } 
    else if (strncmp(cmd, "SET_PID", 7) == 0) {
        float kp, ki, kd;
        if (sscanf(cmd, "SET_PID %f %f %f", &kp, &ki, &kd) == 3) {
            speed_pid.Kp = kp;
            speed_pid.Ki = ki;
            speed_pid.Kd = kd;
            UART_SendMessage("PID Updated\r\n");
        } else {
            UART_SendMessage("Invalid PID values\r\n");
        }
    }
    else if (strncmp(cmd, "GET_PID", 7) == 0) {
        char msg[64];
        snprintf(msg, sizeof(msg), "KP: %.3f KI: %.3f KD: %.3f\r\n", speed_pid.Kp, speed_pid.Ki, speed_pid.Kd);
        UART_SendMessage(msg);
    }
    else if (strncmp(cmd, "GET_SPEED", 9) == 0) {
        char msg[32];
        snprintf(msg, sizeof(msg), "Current RPM: %u\r\n", Motor.speed_rpm);
        UART_SendMessage(msg);
    }
    else if (strncmp(cmd, "STATUS", 6) == 0) {
        char status_msg[256];
        const char *state_str = "UNKNOWN";
        const char *dir_str = "STOP";
        const char *gate_str = Motor.gate_driver_enabled ? "ENABLED" : "DISABLED";
        const char *fault_str = Motor.fault_active ? "ACTIVE" : "NONE";

        switch (Motor.state) {
            case MOTOR_READY: state_str = "READY"; break;
            case MOTOR_IDLE: state_str = "IDLE"; break;
            case MOTOR_RUNNING: state_str = "RUNNING"; break;
            case MOTOR_STOPPING: state_str = "STOPPING"; break;
            case MOTOR_FAULT: state_str = "FAULT"; break;
            default: break;
        }

        switch (Motor.direction) {
            case MOTOR_FORWARD: dir_str = "FORWARD"; break;
            case MOTOR_BACKWARD: dir_str = "BACKWARD"; break;
            default: dir_str = "STOP"; break;
        }

        snprintf(status_msg, sizeof(status_msg),
                 "State : %s\r\nDirection : %s\r\nTarget RPM : %.0f\r\nSpeed : %d RPM\r\nPWM : %d%%\r\nGate Driver : %s\r\nFault : %s\r\nPID: %.2f %.2f %.2f\r\n",
                 state_str, dir_str, Motor.target_rpm, Motor.speed_rpm, Motor.pwm_duty, gate_str, fault_str, speed_pid.Kp, speed_pid.Ki, speed_pid.Kd);
        
        UART_SendMessage(status_msg);
    } 
    else if (strncmp(cmd, "RESET", 5) == 0) {
        Motor_ResetFault();
    } 
    else {
        UART_SendMessage("Invalid Command\r\n");
    }
}

