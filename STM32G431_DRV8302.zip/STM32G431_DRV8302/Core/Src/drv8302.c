#include "drv8302.h"

/**
 * @brief Initialize DRV8302
 */
void DRV8302_Init(void)
{
    /* Keep gate driver disabled initially */
    DRV8302_Disable();
}

/**
 * @brief Enable DRV8302 Gate Driver
 */
void DRV8302_Enable(void)
{
    HAL_GPIO_WritePin(DRV_EN_PORT, DRV_EN_PIN, GPIO_PIN_SET);
}

/**
 * @brief Disable DRV8302 Gate Driver
 */
void DRV8302_Disable(void)
{
    HAL_GPIO_WritePin(DRV_EN_PORT, DRV_EN_PIN, GPIO_PIN_RESET);
}
