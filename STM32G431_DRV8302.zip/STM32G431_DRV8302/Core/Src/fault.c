#include "fault.h"
#include "motor.h"
#include "stm32g4xx_hal.h"

/* EXTI pins for DRV8302 faults */
#define nFAULT_PIN GPIO_PIN_0 // Example EXTI pin, will be defined in gpio.c
#define nOCTW_PIN  GPIO_PIN_1 // Example EXTI pin

/**
 * @brief Initialize Fault module
 */
void Fault_Init(void)
{
    // Faults are handled via EXTI. Nothing specific to init here besides GPIO which is done in gpio.c
}

/**
 * @brief EXTI line detection callback.
 * @param GPIO_Pin Specifies the pins connected EXTI line
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    // If either nFAULT or nOCTW goes LOW
    if (GPIO_Pin == nFAULT_PIN || GPIO_Pin == nOCTW_PIN)
    {
        Motor_FaultTriggered();
    }
    // Dispatch Hall sensors (PB6, PB7, PB8)
    else if (GPIO_Pin == GPIO_PIN_6 || GPIO_Pin == GPIO_PIN_7 || GPIO_Pin == GPIO_PIN_8)
    {
        extern void Speed_HallCallback(uint16_t pin);
        Speed_HallCallback(GPIO_Pin);
    }
}
