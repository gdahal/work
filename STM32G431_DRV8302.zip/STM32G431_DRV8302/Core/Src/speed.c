#include "speed.h"
#include "stm32g4xx_hal.h"
#include "motor.h" // For CONTROL_LOOP_PERIOD_S

static volatile uint32_t hall_tick_count = 0;
static uint16_t current_rpm = 0;

// Moving average filter
#define FILTER_SAMPLES 8
static uint16_t rpm_history[FILTER_SAMPLES] = {0};
static uint8_t rpm_index = 0;

static uint8_t previous_hall_state = 0;

void Speed_Init(void)
{
    hall_tick_count = 0;
    current_rpm = 0;
    previous_hall_state = 0;
    for (int i = 0; i < FILTER_SAMPLES; i++) {
        rpm_history[i] = 0;
    }
}

/**
 * @brief Update RPM calculation, called periodically (e.g. 50Hz / 20ms)
 */
void Speed_Update(void)
{
    // Read and reset tick count atomically
    __disable_irq();
    uint32_t ticks = hall_tick_count;
    hall_tick_count = 0;
    __enable_irq();

    // RPM = (edges / (poles * edges_per_elec_rev)) * (60 / dt)
    float mech_revs = (float)ticks / (float)(MOTOR_POLE_PAIRS * HALL_EDGES_PER_ELEC_REV);
    float rps = mech_revs / CONTROL_LOOP_PERIOD_S;
    
    uint16_t raw_rpm = (uint16_t)(rps * 60.0f);
    
    // Moving average filter
    rpm_history[rpm_index] = raw_rpm;
    rpm_index = (rpm_index + 1) % FILTER_SAMPLES;
    
    uint32_t sum = 0;
    for (int i = 0; i < FILTER_SAMPLES; i++) {
        sum += rpm_history[i];
    }
    current_rpm = sum / FILTER_SAMPLES;
}

uint16_t Speed_GetRPM(void)
{
    return current_rpm;
}

/**
 * @brief Get the current Hall sensor state (1 to 6)
 */
uint8_t Speed_GetHallState(void)
{
    uint8_t state = 0;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6) == GPIO_PIN_SET) state |= 0x01;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_SET) state |= 0x02;
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8) == GPIO_PIN_SET) state |= 0x04;
    
    switch(state) {
        case 1: return 1;
        case 3: return 2;
        case 2: return 3;
        case 6: return 4;
        case 4: return 5;
        case 5: return 6;
        default: return 0; // Invalid state
    }
}

/**
 * @brief EXTI callback for Hall sensors
 */
void Speed_HallCallback(uint16_t GPIO_Pin)
{
    uint8_t current_state = Speed_GetHallState();
    
    // Validate Transition
    if (current_state != 0 && previous_hall_state != 0 && current_state != previous_hall_state) {
        uint8_t diff_fwd = (previous_hall_state % 6) + 1; // Expected forward next state
        uint8_t diff_rev = (previous_hall_state + 4) % 6 + 1; // Expected reverse next state (prev-1 wrapping to 6)
        
        if (current_state != diff_fwd && current_state != diff_rev) {
            // Illegal transition! Noise or fault.
            Motor_FaultTriggered();
            return;
        }
    }
    
    if (current_state != previous_hall_state) {
        hall_tick_count++;
        previous_hall_state = current_state;
        
        // Trigger immediate commutation update
        extern void Motor_UpdateCommutation(void);
        Motor_UpdateCommutation();
    }
}
