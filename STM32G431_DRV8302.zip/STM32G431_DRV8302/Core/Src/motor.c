#include "motor.h"
#include "drv8302.h"
#include "uart.h"
#include "speed.h"
#include "pid.h"
#include <stdio.h>

MotorControl_t Motor;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim8;
extern TIM_HandleTypeDef htim2; // 20ms Control Loop

#define TIM_PERIOD 8500  // 20kHz at 170MHz

// Phase States: 0=Float, 1=Active(PWM), 2=Low(GND)
static const uint8_t commutate_table_fwd[6][3] = {
    { 1, 2, 0 }, // State 1: A+, B-
    { 1, 0, 2 }, // State 2: A+, C-
    { 0, 1, 2 }, // State 3: B+, C-
    { 2, 1, 0 }, // State 4: B+, A-
    { 2, 0, 1 }, // State 5: C+, A-
    { 0, 2, 1 }  // State 6: C+, B-
};

static const uint8_t commutate_table_rev[6][3] = {
    { 2, 1, 0 }, // State 1: A-, B+
    { 2, 0, 1 }, // State 2: A-, C+
    { 0, 2, 1 }, // State 3: B-, C+
    { 1, 2, 0 }, // State 4: B+, A-
    { 1, 0, 2 }, // State 5: C+, A-
    { 0, 1, 2 }  // State 6: C+, B-
};

static uint16_t alignment_timer_ms = 0;

/**
 * @brief Initialize motor control structures
 */
void Motor_Init(void)
{
    Motor.state = MOTOR_POWER_ON;
    Motor.direction = MOTOR_STOP;
    Motor.requested_direction = MOTOR_STOP;
    Motor.gate_driver_enabled = false;
    Motor.pwm_duty = 0;
    Motor.target_rpm = 0.0f;
    Motor.current_target_rpm = 0.0f;
    Motor.speed_ramp_rate = DEFAULT_SPEED_RAMP_RATE;
    Motor.speed_rpm = 0;
    Motor.stall_counter = 0;
    
    // Initialize PID (assuming tuning via UART later)
    PID_Init(&speed_pid, 0.1f, 0.05f, 0.0f, 0.0f, 100.0f);
    
    Motor.state = MOTOR_READY;
}

/**
 * @brief Commutate the motor based on Hall state
 */
static void Motor_Commutate(uint8_t state, uint8_t duty)
{
    if (state == 0 || state > 6 || (Motor.state != MOTOR_RUNNING && Motor.state != MOTOR_ALIGNING)) {
        // Floating all phases
        htim1.Instance->CCER &= ~(TIM_CCER_CC1E | TIM_CCER_CC1NE | TIM_CCER_CC2E | TIM_CCER_CC2NE);
        htim8.Instance->CCER &= ~(TIM_CCER_CC1E | TIM_CCER_CC1NE);
        htim1.Instance->CCR1 = 0;
        htim1.Instance->CCR2 = 0;
        htim8.Instance->CCR1 = 0;
        return;
    }

    uint32_t pulse = (uint32_t)(duty * TIM_PERIOD) / 100;
    
    uint32_t ccer1 = htim1.Instance->CCER;
    uint32_t ccer8 = htim8.Instance->CCER;
    
    // Clear enable bits
    ccer1 &= ~(TIM_CCER_CC1E | TIM_CCER_CC1NE | TIM_CCER_CC2E | TIM_CCER_CC2NE);
    ccer8 &= ~(TIM_CCER_CC1E | TIM_CCER_CC1NE);

    uint32_t ccr1_1 = 0, ccr1_2 = 0, ccr8_1 = 0;
    
    const uint8_t *table = (Motor.direction == MOTOR_FORWARD) ? commutate_table_fwd[state - 1] : commutate_table_rev[state - 1];

    // Phase A (TIM1 CH1)
    if (table[0] == 1) { ccr1_1 = pulse; ccer1 |= (TIM_CCER_CC1E | TIM_CCER_CC1NE); }
    else if (table[0] == 2) { ccr1_1 = 0; ccer1 |= (TIM_CCER_CC1E | TIM_CCER_CC1NE); }
    
    // Phase B (TIM1 CH2)
    if (table[1] == 1) { ccr1_2 = pulse; ccer1 |= (TIM_CCER_CC2E | TIM_CCER_CC2NE); }
    else if (table[1] == 2) { ccr1_2 = 0; ccer1 |= (TIM_CCER_CC2E | TIM_CCER_CC2NE); }

    // Phase C (TIM8 CH1)
    if (table[2] == 1) { ccr8_1 = pulse; ccer8 |= (TIM_CCER_CC1E | TIM_CCER_CC1NE); }
    else if (table[2] == 2) { ccr8_1 = 0; ccer8 |= (TIM_CCER_CC1E | TIM_CCER_CC1NE); }

    htim1.Instance->CCR1 = ccr1_1;
    htim1.Instance->CCR2 = ccr1_2;
    htim8.Instance->CCR1 = ccr8_1;
    
    htim1.Instance->CCER = ccer1;
    htim8.Instance->CCER = ccer8;
}

/**
 * @brief Triggered by Hall Sensor EXTI or PID Loop to update phases
 */
void Motor_UpdateCommutation(void)
{
    if (Motor.state == MOTOR_RUNNING) {
        Motor_Commutate(Speed_GetHallState(), Motor.pwm_duty);
    } else if (Motor.state == MOTOR_ALIGNING) {
        Motor_Commutate(1, ALIGNMENT_DUTY_CYCLE); // Force state 1
    } else {
        Motor_Commutate(0, 0); // Float
    }
}

/**
 * @brief Stop PWM generation safely
 */
static void Stop_PWM(void)
{
    Motor_Commutate(0, 0);
    htim1.Instance->BDTR &= ~TIM_BDTR_MOE;
    htim8.Instance->BDTR &= ~TIM_BDTR_MOE;
}

/**
 * @brief Start PWM generation based on current duty cycle
 */
static void Start_PWM(void)
{
    htim1.Instance->BDTR |= TIM_BDTR_MOE;
    htim8.Instance->BDTR |= TIM_BDTR_MOE;
    
    // Start timers
    htim8.Instance->CR1 |= TIM_CR1_CEN;
    htim1.Instance->CR1 |= TIM_CR1_CEN; // Master starts both
    
    Motor_UpdateCommutation();
}

/**
 * @brief Enable Motor and Gate Driver
 */
void Motor_Enable(void)
{
    if (Motor.state == MOTOR_READY || Motor.state == MOTOR_IDLE) {
        DRV8302_Enable();
        Motor.gate_driver_enabled = true;
        Motor.state = MOTOR_IDLE;
        UART_SendMessage("Motor Enabled\r\n");
    }
}

/**
 * @brief Disable Motor and Gate Driver
 */
void Motor_Disable(void)
{
    Stop_PWM();
    DRV8302_Disable();
    Motor.gate_driver_enabled = false;
    Motor.state = MOTOR_READY;
    Motor.direction = MOTOR_STOP;
    UART_SendMessage("Motor Disabled\r\n");
}

/**
 * @brief Start Motor rotation (enters alignment first)
 */
void Motor_Start(void)
{
    if (Motor.state == MOTOR_IDLE) {
        Motor.direction = Motor.requested_direction;
        Motor.current_target_rpm = 0.0f;
        Motor.stall_counter = 0;
        
        PID_Reset(&speed_pid);
        
        Motor.state = MOTOR_ALIGNING;
        alignment_timer_ms = 0;
        Start_PWM();
        UART_SendMessage("Motor Aligning...\r\n");
    }
}

/**
 * @brief Stop Motor rotation
 */
void Motor_Stop(void)
{
    if (Motor.state == MOTOR_RUNNING || Motor.state == MOTOR_ALIGNING) {
        Motor.state = MOTOR_STOPPING;
        Motor.target_rpm = 0.0f;
        PID_Reset(&speed_pid);
        UART_SendMessage("Motor Stopping...\r\n");
    }
}

void Motor_SetForward(void)
{
    if (Motor.direction == MOTOR_FORWARD || Motor.requested_direction == MOTOR_FORWARD) return;
    Motor.requested_direction = MOTOR_FORWARD;
    
    if (Motor.state == MOTOR_RUNNING) {
        // Safe reverse
        Motor.state = MOTOR_STOPPING;
        Motor.target_rpm = 0.0f;
        PID_Reset(&speed_pid);
    }
}

void Motor_SetBackward(void)
{
    if (Motor.direction == MOTOR_BACKWARD || Motor.requested_direction == MOTOR_BACKWARD) return;
    Motor.requested_direction = MOTOR_BACKWARD;
    
    if (Motor.state == MOTOR_RUNNING) {
        Motor.state = MOTOR_STOPPING;
        Motor.target_rpm = 0.0f;
        PID_Reset(&speed_pid);
    }
}

void Motor_SetSpeed(uint16_t rpm)
{
    Motor.target_rpm = (float)rpm;
}

void Motor_FaultTriggered(void)
{
    Stop_PWM();
    DRV8302_Disable();
    Motor.gate_driver_enabled = false;
    Motor.state = MOTOR_FAULT;
    Motor.direction = MOTOR_STOP;
    Motor.current_target_rpm = 0.0f;
    PID_Reset(&speed_pid);
    UART_SendMessage("HARDWARE FAULT DETECTED!\r\n");
}

void Motor_ResetFault(void)
{
    if (Motor.state == MOTOR_FAULT) {
        Motor.state = MOTOR_READY;
        UART_SendMessage("Fault Reset\r\n");
    }
}

/**
 * @brief State Machine Processing (called in main loop)
 */
void Motor_Process(void)
{
    // Handle safe direction change completion
    if (Motor.state == MOTOR_IDLE && Motor.requested_direction != Motor.direction) {
        if (Motor.requested_direction != MOTOR_STOP) {
            Motor_Start();
        }
    }
}

/**
 * @brief 50Hz (20ms) Control Loop for PID, Profiling, and Protection
 */
void Motor_ControlLoop(void)
{
    // Update RPM here so it syncs exactly with PID calculation
    Speed_Update();
    Motor.speed_rpm = Speed_GetRPM();

    if (Motor.state == MOTOR_ALIGNING) {
        alignment_timer_ms += (uint16_t)(CONTROL_LOOP_PERIOD_S * 1000);
        if (alignment_timer_ms >= ALIGNMENT_TIME_MS) {
            Motor.state = MOTOR_RUNNING;
            UART_SendMessage("Motor Running\r\n");
            // Sync with actual Hall state
            Motor_UpdateCommutation();
        }
        return;
    }

    if (Motor.state == MOTOR_RUNNING || Motor.state == MOTOR_STOPPING) {
        
        // Ramping Logic
        float step = Motor.speed_ramp_rate * CONTROL_LOOP_PERIOD_S;
        
        if (Motor.current_target_rpm < Motor.target_rpm) {
            Motor.current_target_rpm += step;
            if (Motor.current_target_rpm > Motor.target_rpm) Motor.current_target_rpm = Motor.target_rpm;
        } else if (Motor.current_target_rpm > Motor.target_rpm) {
            Motor.current_target_rpm -= step;
            if (Motor.current_target_rpm < Motor.target_rpm) Motor.current_target_rpm = Motor.target_rpm;
        }

        // PID Compute
        PID_Compute(&speed_pid, Motor.current_target_rpm, (float)Motor.speed_rpm, CONTROL_LOOP_PERIOD_S);
        Motor.pwm_duty = (uint8_t)speed_pid.Output;
        
        Motor_UpdateCommutation();
        
        // Stall Detection
        if (Motor.pwm_duty > STALL_PWM_THRESHOLD && Motor.speed_rpm < 10) {
            Motor.stall_counter += (uint16_t)(CONTROL_LOOP_PERIOD_S * 1000);
            if (Motor.stall_counter >= STALL_TIMEOUT_MS) {
                Stop_PWM();
                DRV8302_Disable();
                Motor.state = MOTOR_FAULT;
                UART_SendMessage("STALL DETECTED! MOTOR FAULT.\r\n");
            }
        } else {
            Motor.stall_counter = 0; // Reset if moving or low PWM
        }
        
        // If stopping and speed is low enough, fully stop
        if (Motor.state == MOTOR_STOPPING && Motor.current_target_rpm == 0.0f && Motor.speed_rpm < 10) {
            Stop_PWM();
            Motor.state = MOTOR_IDLE;
            Motor.direction = MOTOR_STOP;
        }
    }
}
