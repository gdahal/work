#include "uart.h"
#include "protocol.h"
#include <string.h>

extern UART_HandleTypeDef huart3;

static uint8_t rx_buffer[UART_RX_BUF_SIZE];
static uint8_t rx_byte;
static uint16_t rx_index = 0;
static volatile uint8_t command_ready = 0;

/**
 * @brief Initialize UART Reception
 */
void UART_Init(void)
{
    HAL_UART_Receive_IT(&huart3, &rx_byte, 1);
}

/**
 * @brief Send a message over UART
 */
void UART_SendMessage(const char *msg)
{
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
}

/**
 * @brief UART Rx Complete Callback
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART3) {
        if (rx_byte == '\n' || rx_byte == '\r') {
            if (rx_index > 0) {
                rx_buffer[rx_index] = '\0';
                command_ready = 1;
            }
        } else {
            if (rx_index < (UART_RX_BUF_SIZE - 1)) {
                rx_buffer[rx_index++] = rx_byte;
            }
        }
        // Re-enable interrupt
        HAL_UART_Receive_IT(&huart3, &rx_byte, 1);
    }
}

/**
 * @brief Process pending UART commands
 */
void UART_Process(void)
{
    if (command_ready) {
        Protocol_ProcessCommand((char *)rx_buffer);
        rx_index = 0;
        command_ready = 0;
    }
}
