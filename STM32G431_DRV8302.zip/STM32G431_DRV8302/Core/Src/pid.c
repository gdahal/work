#include "pid.h"

/**
 * @brief Initialize the PID Controller
 */
void PID_Init(PID_Controller *pid, float kp, float ki, float kd, float out_min, float out_max)
{
    pid->Kp = kp;
    pid->Ki = ki;
    pid->Kd = kd;
    pid->OutputMin = out_min;
    pid->OutputMax = out_max;
    
    // Anti-windup limits for integral term
    pid->IntegralMax = out_max;
    pid->IntegralMin = out_min;

    PID_Reset(pid);
}

/**
 * @brief Reset the PID Controller state
 */
void PID_Reset(PID_Controller *pid)
{
    pid->Integral = 0.0f;
    pid->PreviousError = 0.0f;
    pid->Output = 0.0f;
}

/**
 * @brief Compute PID output
 * @param pid Pointer to PID_Controller struct
 * @param setpoint Target value
 * @param measured Actual measured value
 * @param dt Time delta in seconds since last compute
 */
void PID_Compute(PID_Controller *pid, float setpoint, float measured, float dt)
{
    float error = setpoint - measured;

    // Proportional
    float p_term = pid->Kp * error;

    // Integral
    pid->Integral += pid->Ki * error * dt;

    // Anti-windup clamping
    if (pid->Integral > pid->IntegralMax) {
        pid->Integral = pid->IntegralMax;
    } else if (pid->Integral < pid->IntegralMin) {
        pid->Integral = pid->IntegralMin;
    }

    // Derivative
    float derivative = 0.0f;
    if (dt > 0.0f) {
        derivative = (error - pid->PreviousError) / dt;
    }
    float d_term = pid->Kd * derivative;

    // Total Output
    pid->Output = p_term + pid->Integral + d_term;

    // Saturation
    if (pid->Output > pid->OutputMax) {
        pid->Output = pid->OutputMax;
    } else if (pid->Output < pid->OutputMin) {
        pid->Output = pid->OutputMin;
    }

    pid->PreviousError = error;
}
